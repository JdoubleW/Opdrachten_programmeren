letters = ('A', 'C', 'B', 'A','C','A','C','B','C','A','C','B')

lijst =[letters.count('A'),(letters.count('B')),letters.count('C')]

print(sorted(lijst))