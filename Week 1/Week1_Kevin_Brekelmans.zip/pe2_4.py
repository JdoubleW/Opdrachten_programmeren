uurloon = input('Wat is je uurloon?')
gewerkt = input('Hoeveel uur heb je gewerkt deze week?')
totaal = float(uurloon) * float(gewerkt)

print(gewerkt, 'uur werken levert ', totaal, '€ op!')